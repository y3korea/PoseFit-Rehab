# Reproducibility assets

`PoseFitRehab_functional_verification.ipynb` runs unchanged in Google Colab because it has no external Python dependencies. `run_functional_verification.py` is the same deterministic test harness for local execution.

```bash
python3 run_functional_verification.py
```

Expected terminal output: `11/11 deterministic functional checks passed`.

The harness mirrors the client-side geometry, low-visibility guard, thresholds, and squat repetition hysteresis in the static v2 prototype. It uses generated landmarks and a synthetic state sequence only. A visibility value of 0.0 is used to confirm that the implementation suppresses measurements and returns its quality warning. It cannot estimate pose accuracy, latency on a device, clinical safety, effectiveness, or usability. The public repository URL is recorded in the notebook; the `v0.1.1` tag identifies the initial manuscript release.
