"""Deterministic functional tests mirroring the decision rules in PoseFit Rehab v2.

This script uses synthetic landmarks only. Passing tests prove control-flow behavior,
not pose-estimation accuracy, safety, or clinical effectiveness.
"""
from __future__ import annotations
import csv
import math
from pathlib import Path

GATE = {
    "squat": {"minKnee": 90, "maxTrunkLean": 30, "maxSymDiff": 12},
    "knee_ext": {"minKnee": 120, "maxTrunkLean": 30, "maxSymDiff": 12},
}
QUALITY_LANDMARKS = (23, 24, 25, 26, 27, 28, 11, 12)

def angle_at(a, b, c):
    ab = {"x": a["x"]-b["x"], "y": a["y"]-b["y"]}
    cb = {"x": c["x"]-b["x"], "y": c["y"]-b["y"]}
    magnitude = math.hypot(ab["x"], ab["y"])*math.hypot(cb["x"], cb["y"])
    if not magnitude:
        return 180.0
    return math.degrees(math.acos(min(1, max(-1, (ab["x"]*cb["x"]+ab["y"]*cb["y"])/magnitude))))

def trunk_lean_deg(shoulder, hip):
    dx, dy = shoulder["x"]-hip["x"], shoulder["y"]-hip["y"]
    return 90.0 if abs(dy) < 1e-6 else math.degrees(math.atan2(abs(dx), abs(dy)))

def point_for_knee_angle(angle, x0):
    theta = math.radians(angle)
    hip = {"x": x0, "y": 0.0}
    knee = {"x": x0, "y": 1.0}
    ankle = {"x": x0+math.sin(theta), "y": 1.0-math.cos(theta)}
    return hip, knee, ankle

def landmarks(left_knee=100, right_knee=100, trunk=0, visibility=1.0):
    lm = [{"x": 0.0, "y": 0.0, "visibility": visibility} for _ in range(33)]
    for hip_i, knee_i, ankle_i, angle, x0 in [(23,25,27,left_knee,0.0),(24,26,28,right_knee,5.0)]:
        hip, knee, ankle = point_for_knee_angle(angle, x0)
        lm[hip_i], lm[knee_i], lm[ankle_i] = hip, knee, ankle
    dx, dy = math.sin(math.radians(trunk)), math.cos(math.radians(trunk))
    lm[11] = {"x": lm[23]["x"]+dx, "y": lm[23]["y"]-dy}
    lm[12] = {"x": lm[24]["x"]+dx, "y": lm[24]["y"]-dy}
    for index in QUALITY_LANDMARKS:
        lm[index]["visibility"] = visibility
    return lm

def analyze(lm, exercise="squat"):
    if any((lm[i].get("visibility") if lm[i].get("visibility") is not None else 1) < 0.4 for i in QUALITY_LANDMARKS):
        return {"knee": None, "trunk": None, "sym": None, "issues": ["qual"]}
    lk = angle_at(lm[23], lm[25], lm[27]); rk = angle_at(lm[24], lm[26], lm[28])
    knee, symmetry = min(lk, rk), abs(lk-rk)
    trunk = max(trunk_lean_deg(lm[11],lm[23]), trunk_lean_deg(lm[12],lm[24]))
    limits, issues = GATE[exercise], []
    if knee < limits["minKnee"]: issues.append("knee")
    if trunk > limits["maxTrunkLean"]: issues.append("trunk")
    if symmetry > limits["maxSymDiff"]: issues.append("sym")
    return {"knee":knee,"trunk":trunk,"sym":symmetry,"issues":issues}

def repetition_count(angles):
    reps, in_squat = 0, False
    for knee in angles:
        if not in_squat and knee < 118: in_squat = True
        elif in_squat and knee > 152: in_squat, reps = False, reps+1
    return reps

tests = [
    ("90-degree angle geometry", abs(angle_at({"x":0,"y":0},{"x":0,"y":1},{"x":1,"y":1})-90)<1e-8),
    ("180-degree angle geometry", abs(angle_at({"x":0,"y":0},{"x":0,"y":1},{"x":0,"y":2})-180)<1e-8),
    ("Low-visibility quality gate", analyze(landmarks(visibility=0.0)) == {"knee":None,"trunk":None,"sym":None,"issues":["qual"]}),
    ("Knee threshold equality", "knee" not in analyze(landmarks(90,90))["issues"]),
    ("Knee threshold breach", "knee" in analyze(landmarks(89,89))["issues"]),
    ("Trunk threshold equality", "trunk" not in analyze(landmarks(100,100,30))["issues"]),
    ("Trunk threshold breach", "trunk" in analyze(landmarks(100,100,31))["issues"]),
    ("Symmetry threshold equality", "sym" not in analyze(landmarks(102,90))["issues"]),
    ("Symmetry threshold breach", "sym" in analyze(landmarks(103,90))["issues"]),
    ("Block-warning co-occurrence", set(analyze(landmarks(89,89,31))["issues"]) == {"knee","trunk"}),
    ("One repetition hysteresis cycle", repetition_count([160,117,116,151,153]) == 1),
]
rows = [{"test":name,"expected":"pass","observed":"pass" if ok else "fail","status":"PASS" if ok else "FAIL"} for name, ok in tests]
if not all(row["status"] == "PASS" for row in rows): raise AssertionError(rows)
with Path(__file__).with_name("functional_verification_results.csv").open("w",newline="",encoding="utf-8") as f:
    writer=csv.DictWriter(f,fieldnames=rows[0].keys(),lineterminator="\n"); writer.writeheader(); writer.writerows(rows)
print(f"{len(rows)}/{len(rows)} deterministic functional checks passed")
