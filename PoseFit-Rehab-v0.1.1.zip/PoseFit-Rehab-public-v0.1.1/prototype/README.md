# PoseFit Rehab v2

의료진이 처방하고, 안전 게이트가 검증하고, AI 코치는 매일 곁에 있습니다.
Clinician-directed. Guardrail-verified. Coaching every day.

**인허가 전 연구 프로토타입** · 진단·치료 결정 목적이 아니며, 모든 수치는 시뮬레이션 또는 선행연구 벤치마크입니다.

## 이 저장소는

`posefit-rehab-v1.1`의 후속 v2 단일 파일 쇼케이스입니다. 기존 v1.1의 한계(포즈 추정이 시뮬레이션으로만 되어 있고 실제 MediaPipe가 배선되지 않음)를 해결하고, 2026년 최신 특허·논문·경쟁사를 반영해 한 파일로 재구성했습니다.

- **단일 파일** `index.html` — CSS·JS 모두 내장. 빌드 단계 없음.
- **실제 마커리스 포즈 추정** — MediaPipe Pose Landmarker(33점)를 CDN 동적 `import()`로 로드. GPU delegate, `runningMode: VIDEO`.
- **결정론적 Clinical Safety Gate** — LLM 바깥의 규칙 엔진이 무릎 과굴곡·상체 쏠림·좌우 비대칭·입력 품질을 실시간 판정. LLM은 미호출.
- **카메라 없이 시연** — 샘플 스틱 피겨 모드로 카메라 권한 없이 게이트·반복 카운터를 확인 가능.
- **접근성** — 쉬운 화면(Easy View, 큰 글씨·고대비·음성 안내), 다크 모드, WCAG 2.2 AA 지향.

## 실행

브라우저에서 `index.html`을 직접 열면 됩니다.

```bash
# 로컬 서버(선택)
python3 -m http.server 8000
# → http://localhost:8000
```

카메라 사용 시 HTTPS 또는 `localhost`가 필요합니다(브라우저의 `getUserMedia` 정책).

## 배포 (Vercel)

빌드 스텝이 필요 없는 정적 사이트입니다.

```bash
npm i -g vercel
vercel        # 이 폴더에서 실행, "No" framework 선택
# 또는
vercel --prod
```

`vercel.json`에 `camera=(self)` Permissions-Policy와 보안 헤더가 포함되어 있습니다.

## 구조

```
posefit-rehab-v2.0/
├── index.html   # 전체 사이트 (CSS·JS·데모 내장)
├── vercel.json  # 정적 배포 + 보안 헤더
└── README.md
```

## 4개 MVP 모듈

1. **Clinical Safety Gate + Omission Guard** — FITT-VP 완결성·수술 후 단계·ROM/부하 한계·금기·레드플래그 검증 + 누락 보완.
2. **Evidence-Grounded RAG** — 문장 단위 인용 + 근거등급 배지, 근거 없으면 기권.
3. **Two-Speed Home Coach** — 세트 중 사전 승인 큐만, LLM은 세트 전후만. 영상 무전송.
4. **Therapist Supervision Console** — 위험 우선순위 알림, AI 제안 vs 치료사 판단, 서명 워크플로.

## 의도된 사용 고지(요약)

의료진이 처방한 홈운동의 수행·순응을 지원하는 도구이며 진단·치료 결정 목적이 아닙니다. 화면의 모든 수치는 시뮬레이션 또는 선행연구 벤치마크입니다.

## 주요 출처

2026년 갱신 논문·특허·경쟁사는 푸터의 "주요 출처" 목록에 링크와 함께 정리되어 있습니다.
